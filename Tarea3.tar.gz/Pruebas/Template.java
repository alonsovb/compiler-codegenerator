/*
 * MiniJava Template
 * ACompiler
 * K. Sancho & A. Vega, 2012
 * TEC Costa Rica, Sede San Carlos
 */
class Programa {
    public static void main(String[] a) {
        System.out.println(new MiClase().MiMetodo());
    }
}
class MiClase {
    public int MiMetodo() {
        return 0;
    }
}
